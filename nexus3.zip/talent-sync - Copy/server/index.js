const express = require('express');
const routes = require('./routes');
const mongoose = require('mongoose');
const bodyParser = require('body-parser')
const cors = require('cors')
require('dotenv').config();

const server = express();

// Parse JSON bodies
server.use(express.json());
// Parse URL-encoded bodies
server.use(express.urlencoded({ extended: false }));

server.use(cors())

const port = 3003
const username = 'manoj';
const password = encodeURIComponent('Manoj@7170');
const dbName = 'Talent-Sync';
const MongoDBUri = `mongodb+srv://${username}:${password}@manoj.sqzp9.mongodb.net/${dbName}`;


// Connect MongoDB using Mongoose
mongoose.connect(MongoDBUri, { useNewUrlParser: true, useUnifiedTopology: true })

// Get the default connection
const db = mongoose.connection;

// Event listeners for connection events
db.on('error', console.error.bind(console, "MongoDB connection error:"));
db.once('open', ()=> {
    console.log("MongoDb connected successfully")
})

// Routes 
server.use('/', routes)

// Listening on port 3003
server.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});