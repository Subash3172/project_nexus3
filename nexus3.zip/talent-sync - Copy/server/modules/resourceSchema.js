const mongoose = require('mongoose')

const resourceSchema = new mongoose.Schema({
    name: String,
    doj: Date,
    adhaar: String,
    pan: String,
    education: String,
    createdAt: { type: Date, default: Date.now },
    role: String,
    image: String,
    email: String,
    referral: String,
    organization: String,
    department: String,
    phone: Number,
    Gender: String,
    dob: Date,
    dor: Date,
    bloodGroup: String,
    maritalStatus: String,
})
const resource = mongoose.model('resource', resourceSchema)

module.exports = resource;