const mongoose = require('mongoose');

const requirementSchema = new mongoose.Schema({
    role: {
        type: String,
        
    },
    position: {
        type: String,
        
    },
    salary: {
        type: String,
        
    },
    location: {
        type: String,
        
    },
    description: {
        type: String,
        
    },
    experience: {
        type: String,
        
    },
    workLocation: {
        type: String,
        
    },
    createdBy: {
        type: String,
        
    },
    assignedBy: {
        type: String,
        
    },
    clientId: {
        type: String,
        
    },
    resourceId: {
        type: String,
        
    },
    status: {
        type: String,
        
    },
    interviewDate: {
        type: String,
    },
    interviewTime: {
        type: String,
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: {
        type: Date,
        default: Date.now
    }
});

const Requirement = mongoose.model('Requirement', requirementSchema);

module.exports = Requirement;
