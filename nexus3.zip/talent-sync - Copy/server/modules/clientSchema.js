const mongoose = require('mongoose');

const clientSchema = new mongoose.Schema({
    name:  String,
    organization:  String,
    email: String,
    phone: Number ,
    createdAt:  { type: Date, default: Date.now },
    updatedAt:  Date 
});

module.exports = mongoose.model('Client', clientSchema);