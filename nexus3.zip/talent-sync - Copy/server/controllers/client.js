const express = require('express');
const router = express.Router();
const clientModel = require('../modules/clientSchema');


//Validation
function validateClient(reqBody) {
    const { name, organization, email, phone } = reqBody;
    const errors = [];

    if (!name) {
        errors.push("Name is required");
    }
    if (!organization) {
        errors.push("Organization is required");
    }
    if (!email) {
        errors.push("Email is required");
    }
    if (!phone) {
        errors.push("Phone is required");
    }
    return errors;
}

// Create a new client
router.post('/add-client', async (req, res) => {
    try {
        const validationErrors = validateClient(req.body);
        if (validationErrors.length > 0) {
            const errorMessage = validationErrors.join(', ');
            throw new Error(errorMessage);
        }
        const { name, organization, email, phone } = req.body;
        const newClient = new clientModel({
            name,
            organization,
            email,
            phone:phone, 
        });
        const client = await newClient.save();
        res.status(200).json({ msg: "Client created successfully", data: client });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get all clients
router.get('/', async (req, res) => {
    try {
        const clients = await clientModel.find();
        res.status(200).json({ data: clients });
    } catch (error) {
        res.status(500).json({ error: "Error fetching data" });
    }
});

// Get client by client ID
router.get("/:id", async (req, res) => {
    const id = req.params.id;
    try {
        const client = await clientModel.findById(id);
        if (!client) {
            return res.status(404).json("No Client found");
        }
        res.status(200).json({ data: client });
    } catch (error) {
        res.status(500).json({ error: "Error fetching data" });
    }
});

// Update client by client ID
router.put('/:id', async (req, res) => {
    try {
        const id = req.params.id;
        const updateData = {
            ...req.body,
            updatedAt: new Date(),
        };
        const client = await clientModel.findByIdAndUpdate(id, updateData, { new: true });

        if (!client) {
            return res.status(404).json("No Client found");
        }

        console.log({ updatedClient: client });
        res.status(200).json({ msg: "Client Updated" });
    } catch (error) {
        res.status(500).json({ error: "Error fetching data" });
    }
});


// Delete client by client ID
router.delete('/:id', async (req, res) => {
    try {
        const id = req.params.id;
        const client = await clientModel.findByIdAndDelete(id);
        if (!client) {
            return res.status(404).json({ msg: "Client not found" });
        }
        console.log(client);
        res.status(200).json({ msg: "Client delete successfully" });
    } catch (error) {
        res.status(500).json({ error: "Error fetching data" });
    }
});

module.exports = router;