require('dotenv').config();
const express = require('express')
const axios = require('axios');
const Router = express.Router();
const adminModel = require('../modules/adminSchema')
const bcrypt = require('bcryptjs')
const jwt = require('jsonwebtoken')
const { verifyToken } = require('../middleware/authmiddleware')
const cloudinary = require('../cloudinary/cloudinary')
const mongoose = require('mongoose');



// Register admin
Router.post('/register', async (req, res) => {
    const name = req.body.name;
    const email = req.body.email;
    const password = req.body.password;
    const role = req.body.role;

    // Check if all the fields are  filled in
    if (!email || !password || !role) {
        return res.status(400).json({ msg: "Missing fields" })
    }

    //check if the user already exists in the database
    const admin = await adminModel.findOne({ email: email })
    if (admin) {
        return res.status(409).send("User with this email is already registered")
    }

    // Encrypt password using bcrypt
    const hashedPassword = bcrypt.hashSync(password, 10)

    const newAdmin = new adminModel({
        name: name,
        email: email,
        password: hashedPassword,
        role: role,
    })
    registerAdmin = await newAdmin.save()
    if (registerAdmin) {
        res.status(200).json({ msg: "admin registered successfully", data: registerAdmin })
    }
})

// fetch admin in Hasura
async function fetchAdmin() {
    try {
        const response = await axios.post('https://employee.vinsoftconnected.com/v1/graphql', {
            query: `
                query MyQuery {
                    hr_management(where: {role: {_eq: "6d533846-8bb4-4288-83f8-8e2cdddb1501"}}) {
                    email
                    password
                    name
                    id
                    image
                    }
                }
                `,
        },
            {
                headers: {
                    'x-hasura-admin-secret': 'admin_secret',
                },
            }
        );
        return response.data.data.hr_management;
    } catch (error) {
        console.error('Error fetching data from Hasura:', error);
        throw error;
    }
}
module.exports = fetchAdmin;

// Login Admin
Router.post('/log', async (req, res) => {
    const { email, password } = req.body;

    // Check if email or password is missing
    if (!email || !password) {
        return res.status(400).json({ msg: "Email and password are required" });
    }

    try {
        // Search admin in MongoDB
        const mongoAdmin = await adminModel.findOne({ email: email });

        // Check if the user exists in the MongoDB data
        if (mongoAdmin) {
            // Check if the password is valid
            const validPassword = bcrypt.compareSync(password, mongoAdmin.password);

            if (!validPassword) {
                return res.status(401).json({ msg: "Invalid password" });
            }

            // Generate JWT token
            const token = jwt.sign({ _id: mongoAdmin._id }, process.env.JWT_SECRET, { expiresIn: '1d' });

            return res.status(200).json({ token: token, admin: mongoAdmin.email, message: "Logged in successfully" });
        }

        // Check if the user exists in the Hasura data
        const hasuraData = await fetchAdmin();
        const hasuraAdmin = hasuraData.find(admin => admin.email === email);

        if (!hasuraAdmin) {
            return res.status(401).json({ msg: 'User not found' });
        }

        // Check if the password is valid
        if (password !== hasuraAdmin.password) {
            return res.status(401).json({ msg: "Invalid password" });
        }

        // Generate JWT token
        const token = jwt.sign({ _id: hasuraAdmin.id }, process.env.JWT_SECRET, { expiresIn: '1d' });

        res.status(200).json({ token: token, admin: hasuraAdmin.email, message: "Logged in successfully" });
    } catch (error) {
        console.error("Error Fetching Data:", error);
        res.status(500).json({ msg: "Internal Server Error" });
    }
});


// Login Admin
Router.post('/login', async (req, res) => {
    const email = req.body.email;
    const password = req.body.password;

    // Check if email or password is missing
    try {
        if (!email || !password) {
            return res.status(400).json({ msg: "Email and password are required" });
        }

        // Check if the user exists in the database
        const admin = await adminModel.findOne({ email: email });

        if (!admin) {
            const hasuraAdmin = await fetchAdmin();

            if (!hasuraAdmin) {
                return res.status(401).json({ msg: 'Invalid Email' });
            }
            const admin = await hasuraAdmin.findOne({ email: email });

        }

        // Check if the password is valid
        const validPassword = bcrypt.compareSync(password, admin.password);

        if (!validPassword) {
            return res.status(401).json({ msg: "Invalid password" });
        }

        // Generate JWT token
        const token = jwt.sign({ _id: admin._id }, process.env.JWT_SECRET, { expiresIn: '1d' });

        res.status(200).json({ token: token, admin: admin.email, message: "Logged in successfully" });
    } catch (error) {
        console.log("Error Fetching Data")
        res.status(500).json
    }
});




Router.get('/getAdmin', verifyToken, async (req, res) => {
    try {
        const id = req.user._id;

        const validId = mongoose.Types.ObjectId.isValid(id) ? new mongoose.Types.ObjectId(id) : null;

        if (validId) {
            const adminFromDB = await adminModel.findById(validId).select('-password');

            if (adminFromDB) {
                return res.status(200).json(adminFromDB);
            }
        }
        const hasuraData = await fetchAdmin();
        const hasuraAdmin = hasuraData.find(admin => admin.id === id);

        if (hasuraAdmin) {
            return res.status(200).json(hasuraAdmin);
        } else {
            return res.status(404).json({ msg: 'Admin not found' });
        }
    } catch (error) {
        console.error("Error Fetching Admin Data:", error);
        return res.status(500).json({ msg: "Internal Server Error" });
    }
});



// get all Admins
Router.get('/getAll', verifyToken, async (req, res) => {
    try {
        const admins = await adminModel.find({}).select('-password');
        const hasuraData = await fetchAdmin();

        const combinedData = [...admins, ...hasuraData];
        res.json(combinedData);
    } catch (error) {
        console.error("Error fetching admin data:", error);
        res.status(500).json({ error: "Internal server error" });
    }
});


Router.use('/uploadImage', verifyToken, cloudinary);


module.exports = Router;