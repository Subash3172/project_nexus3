const express = require('express');
const Router = express.Router();
const resourceModel = require('../modules/resourceSchema')

// Create a new resource
Router.post('/add-resource', async (req, res) => {
    try {
        const { name, doj, adhaar, pan, education, role, image, email, referral, organization, department, phone, Gender, dob, dor, bloodGroup, maritalStatus } = req.body;
        const newResource = new resourceModel({
            name, doj, adhaar, pan, education, role, image, email, referral, organization, department, phone, Gender, dob, dor, bloodGroup, maritalStatus
        });
        const resource = await newResource.save();
        res.status(200).json({ msg: "Resource added Successfully" });
        console.log(resource)
    }
    catch (error) {
        res.status(500).json({ error: "Internal server error" });
    }
});

// Get all resource
Router.get('/', async (req, res) => {
    try {
        const resources = await resourceModel.find();
        res.status(200).json({ data: resources })
    } catch (error) {
        res.status(500).json({ error: "Error fetching data" });
    }
});

// Get resource by resource ID
Router.get("/:id", async (req, res) => {
    const id = req.params.id;
    try {
        const resource = await resourceModel.findById(id);
        if (!resource) {
            return res.status(404).json("No Resource found")
        }
        res.status(200).json({ data: resource })
    } catch (error) {
        res.status(500).json({ error: "Error fetching data" })
    }
})

// Update resource by resource ID
Router.put('/:id', async (req, res) => {
    try {
        const id = req.params.id;
        const resource = await resourceModel.findByIdAndUpdate(id, req.body, { new: true })
        if (!resource) {
            return res.status(404).json("No Resource found")
        }
        console.log({ deletedResource: resource })
        res.status(200).json({ msg: "Resource Updated" })
    } catch (error) {
        res.status(500).json({ error: "Error fetching data" })
    }
})

// Delete resource by resource ID
Router.delete('/:id', async (req, res) => {
    try{
        const id = req.params.id;
        const resource = await resourceModel.findByIdAndDelete(id);
        if(!resource){
            return res.status(404).json({msg:"Resource not found"})
        }
        console.log(resource);
        res.status(200).json({msg:"Resource delete successfully"})
    }catch(error){
        res.status(500).json({error:"Error fetching data"})
    }
})

module.exports = Router;