const express = require('express');
const router = express.Router();
const requirementsModel = require('../modules/requirementsSchema');


// Validation
function validateRequirement(reqBody) {
    const { role, position, salary, location, description, experience, workLocation, createdBy, assignedBy, status } = reqBody;

    const errors = [];

    if (!role) {
        errors.push("role title is required");
    }
    if (!position) {
        errors.push("position is required");
    }
    if (!salary) {
        errors.push("salary is required");
    }
    if (!location) {
        errors.push("location is required");
    }
    if (!description) {
        errors.push("description is required");
    }
    if (!experience) {
        errors.push("experience by is required");
    }
    if (!workLocation) {
        errors.push("workLocation to is required");
    }
    if (!createdBy) {
        errors.push("createdBy ID is required");
    }
    if (!assignedBy) {
        errors.push("assignedBy ID is required");
    }
    if (!status) {
        errors.push("status is required");
    }

    return errors;
}

// Create a new requirement
router.post('/add-requirement', async (req, res) => {
    try {
        const validationErrors = validateRequirement(req.body);
        if (validationErrors.length > 0) {
            const errorMessage = validationErrors.join(', ');
            throw new Error(errorMessage);
        }
        const { role, position, salary, location, description, experience, workLocation, createdBy, assignedBy, status } = req.body;
        const newRequirement = new requirementsModel({
            role,
            position,
            salary,
            location,
            description,
            experience,
            workLocation,
            createdBy,
            assignedBy,
            status,
            createdAt: new Date(),
            updatedAt: new Date()
        });
        const requirement = await newRequirement.save();
        res.status(200).json({ msg: "Requirement created successfully", data: requirement });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Error handling
function errorHandler(res, error) {
    console.error(error);
    res.status(500).json({ error: "Internal server error" });
}

// Get all requirements
router.get('/', async (req, res) => {
    try {
        const requirements = await requirementsModel.find();
        res.status(200).json({ data: requirements });
    } catch (error) {
        errorHandler(res, error);
    }
});

// Get requirement by requirement ID
router.get("/:id", async (req, res) => {
    const id = req.params.id;
    try {
        const requirement = await requirementsModel.findById(id);
        if (!requirement) {
            return res.status(404).json({ error: "No Requirement found" });
        }
        res.status(200).json({ data: requirement });
    } catch (error) {
        errorHandler(res, error);
    }
});

// Update requirement by requirement ID
router.put('/:id', async (req, res) => {
    try {
        const id = req.params.id;
        const updateData = {
            ...req.body,
            updatedAt: new Date(),
        };

        const requirement = await requirementsModel.findByIdAndUpdate(id, updateData, { new: true });

        if (!requirement) {
            return res.status(404).json({ error: "Requirement not found" });
        }

        res.status(200).json({ msg: "Requirement updated successfully", data: requirement });
    } catch (error) {
        errorHandler(res, error);
    }
});

// Delete requirement by requirement ID
router.delete('/:id', async (req, res) => {
    try {
        const id = req.params.id;
        const requirement = await requirementsModel.findByIdAndDelete(id);

        if (!requirement) {
            return res.status(404).json({ error: "Requirement not found" });
        }

        res.status(200).json({ msg: "Requirement deleted successfully" });
    } catch (error) {
        errorHandler(res, error);
    }
});

module.exports = router;
