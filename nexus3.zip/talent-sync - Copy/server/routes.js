// routes.js
const express = require('express');
const router = express.Router();
const { combinedRouter } = require('./controllers/combinedresources');
const { verifyToken } = require('./middleware/authmiddleware');


router.use('/test', verifyToken, require('./exGetApi'));
router.use('/admin', require('./controllers/admin'));
router.use('/resource', verifyToken, require('./controllers/resource'));
router.use('/client', verifyToken, require('./controllers/client'));
router.use('/requirements', verifyToken, require('./controllers/requirements'));
router.use('/sendMail', verifyToken, require('./controllers/sendInterviewEmails'));
router.use('/internalResource', verifyToken, require('./controllers/internalresources'));

router.use('/combined-resources', combinedRouter)


module.exports = router;
