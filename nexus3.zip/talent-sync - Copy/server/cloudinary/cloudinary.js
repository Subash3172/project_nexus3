const cloudinary = require('cloudinary').v2;
require('dotenv').config();
const express = require('express');
const Router = express.Router();
const adminModel = require('../modules/adminSchema')


// Configure Cloudinary
cloudinary.config({
    cloud_name: process.env.CLOUD_NAME,
    api_key: process.env.API_KEY,
    api_secret: process.env.API_SECRET
});

Router.post('/', async (req, res) => {
    try {
        if (!req.body.image) {
            return res.status(400).json({ error: 'No file uploaded' });
        }
        const adminId = req.user._id; // get the id of the logged in user from the token
        if (!adminId) {
            return res.status(400).json({ error: 'Cannot get admin ID' });
        }
        const admin = await adminModel.findOne({ _id: adminId })
        if (!admin) {
            return res.status(400).json({ error: 'Admin does not found in Database' });
        }
        const uploadImage = await cloudinary.uploader.upload(req.body.image, {
            upload_preset: "unsigned_upload",
            allowed_formats: ['png', 'jpg', 'jpeg', 'svg']
        });
        console.log(uploadImage.secure_url)

        res.status(200).json(uploadImage);

        await adminModel.findByIdAndUpdate(adminId, { image: uploadImage.secure_url }, { new: true });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'An error occurred while uploading the image' });
    }
});

module.exports = Router;
