const express = require('express')
const router = express.Router()

router.get('/api', (req, res) => {
    res.status(200).json({ message: "Api get successful", data: "Yuvaraj" })
    console.log('successful')
})

module.exports = router;

