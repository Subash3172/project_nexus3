const { addWebpackAlias, override } = require('customize-cra');

module.exports = override(
  addWebpackAlias({
    // Add aliases for crypto and stream to resolve-browserify
    'crypto': require.resolve('crypto-browserify'),
    'stream': require.resolve('stream-browserify')
  })
);
