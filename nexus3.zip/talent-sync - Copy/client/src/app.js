import React, { useEffect } from 'react';
import SignInForm from './components/pages/login'
import Sidebar from './components/layouts/sidebar';
import Dashboard from './components/dashboard/dashboard';
import Client from './components/client/client';
import Resource from './components/resource/resource';
import Admin from './components/admin/admin';
import 'bootstrap/dist/css/bootstrap.min.css';
import './styles/App.css'
import './styles/global.css'
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { authentication } from './features/authentication/authAction';

function App() {

    const dispatch = useDispatch();
    const isAuthenticated = useSelector((state) => state.auth.isAuthenticated);
  
    useEffect(() => {
      dispatch(authentication());
    }, [dispatch]);
    

    return (
        <BrowserRouter>
            {!isAuthenticated ? (
                <div className="app-container">
                    <Routes>
                        <Route path="/" element={<SignInForm />} />
                    </Routes>
                </div>
            ) : (
                <div className="app-container">
                    <Sidebar />
                    <div className="main-content">
                        <Routes>
                            <Route path="/" element={<Dashboard />} />
                            <Route path="/Client" element={<Client />} />
                            <Route path="/Resource" element={<Resource />} />
                            <Route path="/admin" element={<Admin />} />
                        </Routes>
                    </div>
                </div>
            )}
        </BrowserRouter>
    );
}

export default App;




