// reportWebVitals.js
export function reportWebVitals(metric) {
    // Implement reporting logic here
    console.log(metric);
  }