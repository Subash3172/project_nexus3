import React from 'react';

const Header = () => {

  return (
    <div className="dashboard-container">
      <p>This is Header</p>
    </div>
  );
};

export default Header;
