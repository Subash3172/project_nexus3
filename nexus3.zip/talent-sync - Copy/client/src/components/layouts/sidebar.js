import React, { useState } from 'react';
import '../../styles/sidebar.css';
import { Link, useLocation } from 'react-router-dom';
import { logOut } from '../../features/authentication/authAction';
import { useDispatch } from 'react-redux';
import ProfileImg from '../../assets/noImage.png';
import TalentSync from '../../assets/talentSync.png';
import Dashboard from '../../assets/dashboard.png';
import Client from '../../assets/client.png';
import Resource from '../../assets/resource.png';
import Admin from '../../assets/admin.png';
import Report from '../../assets/report.png';

function Sidebar() {
    const dispatch = useDispatch();
    const location = useLocation();
    const [activeMenu, setActiveMenu] = useState('');

    const handleLogout = () => {
        dispatch(logOut());
        window.location.href = '/';
    }

    const handleDropDown = () => { }

    const handleMenuClick = (menuName) => {
        setActiveMenu(menuName);
    }

    return (
        <div className='sidebarBorder'>
            <div className="sidebar">
                <div className="talent-sync-container">
                    <img alt='talentSync' src={TalentSync} />
                    <span>Talent Sync</span>
                </div>
                <div className='sidebar-menu'>
                    <Link to="/" onClick={() => handleMenuClick('dashboard')} className={activeMenu === 'dashboard' ? 'active' : ''}><img alt='dashboard' src={Dashboard} /><span>Dashboard</span></Link>
                    <Link to="/client" onClick={() => handleMenuClick('client')} className={activeMenu === 'client' ? 'active' : ''}><img alt='client' src={Client} /><span>Client</span></Link>
                    <Link to="/resource" onClick={() => handleMenuClick('resource')} className={activeMenu === 'resource' ? 'active' : ''}><img alt='resource' src={Resource} /><span>Resource</span></Link>
                    <Link to="/admin" onClick={() => handleMenuClick('admin')} className={activeMenu === 'admin' ? 'active' : ''}><img alt='admin' src={Admin} /><span>Admin</span></Link>
                    <Link to="/report" onClick={() => handleMenuClick('report')} className={activeMenu === 'report' ? 'active' : ''}><img alt='report' src={Report} /><span>Report</span></Link>
                </div>
                <div className="profile-container">
                    <img alt='profile' className="profile-img" src={ProfileImg} onClick={handleDropDown} />
                    <div className='profileDropdown'>
                        <ul>
                            <li>Profile</li>
                            <li>Change Password</li>
                            <li>Switch Account</li>
                            <li><Link to="/logout" className="logout-button" onClick={handleLogout}>Logout</Link></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Sidebar;
