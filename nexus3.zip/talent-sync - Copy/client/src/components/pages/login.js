import React, { useState } from "react";
import { useDispatch } from 'react-redux';
import { FaEye, FaEyeSlash } from "react-icons/fa";
import "../../styles/login.css";
import { ApolloClient, InMemoryCache, gql } from '@apollo/client';
import { authenticateUser } from '../../features/authentication/authAction';


const client = new ApolloClient({
  uri: "https://employee.vinsoftconnected.com/v1/graphql",
  cache: new InMemoryCache(),
  headers: {
    "x-hasura-admin-secret": "admin_secret",
  },
});

const GET_DATA = gql`
  query GetData($email: String!) {
    hr_management(where: { email: { _eq: $email } }) {
      email
      password
      id
      role
    }
  }
`;

const SignInForm = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [emailError, setEmailError] = useState("");
  const [passwordError, setPasswordError] = useState("");

  const dispatch = useDispatch();

  const handleEmailChange = (e) => {
    setEmail(e.target.value);
  };

  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
  };

  const toggleShowPassword = () => {
    setShowPassword(!showPassword);
  };

  const validateInputs = () => {
    const emailFormat = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const passwordFormat = /^(?=.*[!@#$%^&*(),.?":{}|<>])(?=.*[a-z])(?=.*\d).{6,}$/;

    if (!email) {
      setEmailError("Please enter your email");
      return false;
    } else if (!emailFormat.test(email)) {
      setEmailError("Please enter a valid email address");
      return false;
    } else {
      setEmailError("");
    }

    if (!password) {
      setPasswordError("Please enter your password");
      return false;
    } else if (!passwordFormat.test(password)) {
      setPasswordError("Password must contain at least 6 characters including letters, numbers, and special characters");
      return false;
    } else {
      setPasswordError("");
    }

    return true;
  };

  const handleLogin = async () => {
    if (!validateInputs()) return;

    try {
      setLoading(true);
        dispatch(authenticateUser(email, password));
      
    } catch (error) {
      console.error("Error:", error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="split-screen">
      <div className="left">
        <section className="copy">
          <h1>Talent Sync Hub</h1>
        </section>
      </div>
      <div className="right">
        <form>
          <section className="copy">
            <h2>Sign In</h2>
          </section>
          <hr />
          <div className="input-container email">
            <label htmlFor="email">Email:</label>
            <input type="email" placeholder="Ex: mailto:johndoe@gmail.com" name="email" id="Lemail" value={email} onChange={handleEmailChange} />
            {emailError && <span style={{ color: "red" }}>{emailError}</span>}
          </div>
          <div className="input-container password">
  <label htmlFor="password">Password:</label>
  <div className="password-input-wrapper"> {/* Wrap input and icon */}
    <input type={showPassword ? 'text' : 'password'} placeholder="Enter password here" name="password" id="Lpassword" value={password} onChange={handlePasswordChange} />
    <i className="show-password" onClick={toggleShowPassword}>{showPassword ? <FaEye /> : <FaEyeSlash />}</i>
  </div>
  {passwordError && <span style={{ color: "red" }}>{passwordError}</span>}
</div>

          <div className="login-container">
            <a href="#null">Forgot Password?</a>
          </div>
          <hr />
          <button type="button" className="signup-btn" onClick={handleLogin} disabled={loading}>
            {loading ? "Signing In..." : "Sign In"}
          </button>
        </form>
      </div>
    </div>
  );
};

export default SignInForm;
