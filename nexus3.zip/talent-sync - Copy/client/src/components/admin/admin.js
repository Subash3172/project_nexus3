import React, { useState } from 'react';
import axios from 'axios';

const Admin = () => {
  const [file, setFile] = useState(null);
  const [image, setImage] = useState(null);
  const [loading, setLoading] = useState(false);
  const storedToken = localStorage.getItem('token')


  const handleImageChange = (event) => {
    const file = event.target.files[0];
    if (file instanceof Blob) {
      setFile(file);
      setFileToBase(file);
    } else {
      console.error('Invalid file type');
    }
  };

  const setFileToBase = (file) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onloadend = () => {
      setImage(reader.result);
    };
  };

  const onSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);
    try {
      const response = await axios.post('http://localhost:3003/admin/uploadImage', {image},{
        headers: {
          Authorization: `Bearer ${storedToken}`
        }
      });
      alert("Upload Successful!");
      setFile(null);
      setLoading(false);
      console.log(response);
    } catch (err) {
      console.error(err.message);
      alert("Upload Failed!");
      setLoading(false);
    }
  };

  return (
    <div>
      <h2>Admin Profile</h2>
      <p>Upload admin image here</p>
      <form onSubmit={onSubmit}>
        <input type="file" onChange={handleImageChange} />
        {image && <img src={image} alt="Preview" style={{ maxWidth: '100px', maxHeight: '100px' }} />}
        <button type="submit" disabled={!file || loading}>Upload</button>
      </form>
    </div>
  );
};

export default Admin;
