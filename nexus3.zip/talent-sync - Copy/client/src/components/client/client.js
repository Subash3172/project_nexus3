import React, { useEffect, useState } from 'react';
import '../../styles/client.css';
import Table from 'react-bootstrap/Table';
import AddClientModal from './addClientModal';
import EditClientModal from './editClientModal';
import Swal from 'sweetalert2';
import axios from 'axios';
import Modal from 'react-modal';

const Clients = ({ client }) => {
  const [editModalShow, setEditModalShow] = useState(false);
  const [addClientModal, setAddClientModal] = useState(false);
  const [clients, setClients] = useState([]);
  const storedToken = localStorage.getItem('token')

  Modal.setAppElement('#root');

  // Functions for handling modal visibility
  const openModal = () => setAddClientModal(true);
  const closeModal = () => setAddClientModal(false);



  const closeEditModal = () => setEditModalShow(false);

  const handleAddClientSubmit = () => {
    closeModal();
    fetchClientData();
  }
  const handleEditClientSubmit = () => {
    closeEditModal();
    fetchClientData();
  }
  const handleDeleteClient = (clientId) => {
    Swal.fire({
      title: 'Are you sure?',
      text: 'You will not be able to recover this client data!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, keep it'
    }).then((result) => {
      if (result.isConfirmed) {
        axios.delete(`http://localhost:3003/client/${clientId}`, {
          headers: {
            'Authorization': `Bearer ${storedToken}`
          }
        })
          .then((res) => {
            console.log("Deleted Client", res.data);
            fetchClientData();
            Swal.fire(
              'Deleted!',
              'Your client data has been deleted.',
              'success'
            );
          })
          .catch((err) => {
            console.error(`Error deleting client :${err}`);
            Swal.fire(
              'Error!',
              'An error occurred while deleting client data.',
              'error'
            );
          });
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        Swal.fire(
          'Cancelled',
          'Your client data is safe :)',
          'info'
        );
      }
    });
  };


  const fetchClientData = () => {
    axios.get('http://localhost:3003/client/', {
      headers: {
        'Authorization': `Bearer ${storedToken}`
      }
    })
      .then((res) => {
        setClients(res.data.data)
      })
      .catch((err) => {
        console.error(`Error getting clients :${err}`)
      });
  }

  useEffect(() => {
    axios.get('http://localhost:3003/client/', {
      headers: {
        'Authorization': `Bearer ${storedToken}`
      }
    })
      .then((res) => {
        setClients(res.data.data)
      })
      .catch((err) => {
        console.error(`Error getting clients :${err}`)
      });
  }, [storedToken]);

  return (
    <>
      <div className="table">
        <div className="table_header">
          <p>Client Details</p>
          <div className="add_Button">
            <button onClick={openModal} className='add-client'>Add client</button>
            <AddClientModal
              isOpen={addClientModal}
              onClose={closeModal}
              onSubmit={handleAddClientSubmit}
            />
          </div>
        </div>
        <div className="table_section">
          <Table>
            <thead>
              <tr>
                <th scope="col">S.NO</th>
                <th scope="col">Client Name</th>
                <th scope="col">Organization</th>
                <th scope="col">Email</th>
                <th scope="col">Phone Number</th>
                <th scope="col">Actions</th>
              </tr>
            </thead>
            <tbody>
              {clients.map((client, index) => (
                <tr key={index}>
                  <th scope="row">{index + 1}</th>
                  <td>{client.name}</td>
                  <td>{client.organization}</td>
                  <td>{client.email}</td>
                  <td>{client.phone}</td>
                  <td>
                    <button onClick={() => setEditModalShow(client._id)} className='edit-button'>Edit</button>
                    <button onClick={() => handleDeleteClient(client._id)}>Delete</button>
                    <EditClientModal
                      key={client._id}
                      isOpen={editModalShow === client._id}
                      onClose={() => setEditModalShow(null)}
                      onSubmit={handleEditClientSubmit}
                      clientId={client._id}
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
        </div>
      </div>
    </>
  );
};

export default Clients;
