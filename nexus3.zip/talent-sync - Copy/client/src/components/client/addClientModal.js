import axios from 'axios';
import React, { useEffect, useMemo, useState } from 'react';
import Modal from 'react-modal';

const AddClientModal = ({ isOpen, onClose, onSubmit }) => {
  const [admin, setAdmin] = useState([])
  const storedToken = localStorage.getItem('token')
  const initialFormData = useMemo(() => ({
    name: "",
    organization: "",
    email: "",
    phone: "",
  }), []);
  const [formData, setFormData] = useState(initialFormData);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
      createdBy: admin._id || admin.id,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:3003/client/add-client', formData, {
        headers: {
          Authorization: `Bearer ${storedToken}`
        }
      });
      console.log(response.data);
    } catch (error) {
      console.error('Error fetching admin data:', error);
    }
    onSubmit(formData);
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('http://localhost:3003/admin/getAdmin', { headers: { Authorization: `Bearer ${storedToken}` } });
        setAdmin(response.data);
      } catch (error) {
        console.error('Error fetching admin data:', error);
      }
    };

    fetchData();

  }, [storedToken]);


  useEffect(() => {
    if (admin.length > 0) {
      setFormData((prevData) => ({
        ...prevData,
        createdBy: admin._id
      }));
    }
  }, [admin]);

  useEffect(() => {
    if (!isOpen) {
      setFormData(initialFormData);
    }
  }, [isOpen, initialFormData]);

  return (
    <Modal isOpen={isOpen} onRequestClose={onClose}>
      <div className='requirement-modal'>
        <div className='requirement-title-bar'>
          <h2>Add Client</h2>
          <span className="close" onClick={onClose}>&times;</span>
          <div className='requirement-modal-title-line'></div>
        </div>
        <form onSubmit={handleSubmit}>
          <div className='modal-inside-container'>

            <table>
              <tbody>
                <tr>
                  <td><label>Name</label></td>
                  <td>:<input type="text" name="name" value={formData.role} onChange={handleChange} /></td>
                </tr>
                <tr>
                  <td><label>Organization</label></td>
                  <td>:<input type="text" name="organization" value={formData.position} onChange={handleChange} /></td>
                </tr>
                <tr>
                  <td><label>Email</label></td>
                  <td>:<input type="text" name="email" value={formData.salary} onChange={handleChange} /></td>
                </tr>
                <tr>
                  <td><label>PhoneNumber</label></td>
                  <td>:<input type="number" name="phone" value={formData.location} onChange={handleChange} /></td>
                </tr>
              </tbody>
            </table>
          </div>
          <div className='addrequirement-footer'>
            <h3>{admin.name}</h3>
            <button type="submit">Submit</button>
          </div>

        </form>

      </div>
    </Modal>
  );
};

export default AddClientModal;
