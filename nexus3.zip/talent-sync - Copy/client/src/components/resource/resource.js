import React, { useEffect, useState } from 'react';
import '../../styles/client.css';
import Table from 'react-bootstrap/Table';
import AddResourceModal from './addResourceModal';
import EditResourceModal from './editResourceModal';
import Swal from 'sweetalert2';
import axios from 'axios';
import Modal from 'react-modal';

const Resource = ({ client }) => {
  const [editModalShow, setEditModalShow] = useState(false);
  const [addClientModal, setAddClientModal] = useState(false);
  const [resources, setResource] = useState([]);
  const [internalResources, setInternalResources] = useState([]);
  const storedToken = localStorage.getItem('token')

  Modal.setAppElement('#root');

  // Functions for handling modal visibility
  const openModal = () => setAddClientModal(true);
  const closeModal = () => setAddClientModal(false);

  const closeEditModal = () => setEditModalShow(false);

  const handleAddResourceSubmit = () => {
    closeModal();
    fetchClientData();
  }
  const handleEditResourceSubmit = () => {
    closeEditModal();
    fetchClientData();
  }

  const handleDeleteClient = (clientId) => {
    Swal.fire({
      title: 'Are you sure?',
      text: 'You will not be able to recover this client data!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, keep it'
    }).then((result) => {
      if (result.isConfirmed) {
        axios.delete(`http://localhost:3003/resource/${clientId}`, {
          headers: {
            'Authorization': `Bearer ${storedToken}`
          }
        })
          .then((res) => {
            console.log("Deleted Client", res.data);
            fetchClientData();
            Swal.fire(
              'Deleted!',
              'Your client data has been deleted.',
              'success'
            );
          })
          .catch((err) => {
            console.error(`Error deleting client :${err}`);
            Swal.fire(
              'Error!',
              'An error occurred while deleting client data.',
              'error'
            );
          });
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        Swal.fire(
          'Cancelled',
          'Your client data is safe :)',
          'info'
        );
      }
    });
  };

  const hasuraData = () => {
    Swal.fire(
      'Error!',
      'You cannot able to edit internal resources',
      'error'
    );
  }
  const fetchClientData = () => {
    axios.get('http://localhost:3003/combined-resources/', {
      headers: {
        'Authorization': `Bearer ${storedToken}`
      }
    })
      .then((res) => {
        setResource(res.data.mongoData)
        setInternalResources(res.data.hasuraData)
      })
      .catch((err) => {
        console.error(`Error getting resource :${err}`)
      });
  }

  useEffect(() => {
    axios.get('http://localhost:3003/combined-resources/', {
      headers: {
        'Authorization': `Bearer ${storedToken}`
      }
    })
      .then((res) => {
        setResource(res.data.mongoData)
        setInternalResources(res.data.hasuraData)
      })
      .catch((err) => {
        console.error(`Error getting resource :${err}`)
      });
  }, [storedToken]);

  return (
    <>
      <div className="table">
        <div className="table_header">
          <p>Client Details</p>
          <div className="add_Button">
            <button onClick={openModal} className='add-client'>Add client</button>
            <AddResourceModal
              isOpen={addClientModal}
              onClose={closeModal}
              onSubmit={handleAddResourceSubmit}
            />
          </div>
        </div>
        <div className="table_section">
          <Table>
            <thead>
              <tr>
                <th scope="col">S.NO</th>
                <th scope="col">Client Name</th>
                <th scope="col">Organization</th>
                <th scope="col">Email</th>
                <th scope="col">Phone Number</th>
                <th scope="col">Actions</th>
              </tr>
            </thead>
            <tbody>
              {resources.map((resource, index) => (
                <tr key={index}>
                  <th scope="row">{index + 1}</th>
                  <td>{resource.name}</td>
                  <td>{resource.organization}</td>
                  <td>{resource.email}</td>
                  <td>{resource.phone}</td>
                  <td>
                    <button onClick={() => setEditModalShow(resource._id)} className='edit-button'>Edit</button>
                    <button onClick={() => handleDeleteClient(resource._id)}>Delete</button>
                    <EditResourceModal
                      key={resource._id}
                      isOpen={editModalShow === resource._id}
                      onClose={() => setEditModalShow(null)}
                      onSubmit={handleEditResourceSubmit}
                      resourceId={resource._id}
                    />
                  </td>
                </tr>
              ))}
              {internalResources.map((resource, index) => (
                <tr key={index}>
                  <th scope="row">{index + resources.length + 1}</th>
                  <td>{resource.name}</td>
                  <td>{resource.organization}</td>
                  <td>{resource.email}</td>
                  <td>{resource.phone}</td>
                  <td>
                    <button className='edit-button' onClick={hasuraData}>Edit</button>
                    <button onClick={hasuraData}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
        </div>
      </div>
    </>
  );
};

export default Resource;
