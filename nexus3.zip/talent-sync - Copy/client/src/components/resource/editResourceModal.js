import axios from 'axios';
import React, { useEffect, useMemo, useState } from 'react';
import Modal from 'react-modal';
import Swal from 'sweetalert2';

const EditResourceModal = ({ isOpen, onClose, onSubmit, resourceId }) => {
  const [admin, setAdmin] = useState([]);
  const storedToken = localStorage.getItem('token');
  const initialFormData = useMemo(() => ({
    name: "",
    organization: "",
    email: "",
    phone: "",
  }), []);

  const [formData, setFormData] = useState(initialFormData);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
      createdBy: admin._id || admin.id,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.put(`http://localhost:3003/resource/${resourceId}`, formData, {
        headers: {
          Authorization: `Bearer ${storedToken}`,
        },
      }
      );
      Swal.fire({
        icon: 'success',
        title: 'Client Updated',
        text: 'Client data has been updated successfully!',
      });
    } catch (error) {
      console.error('Error fetching admin data:', error);
      // Show error alert
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Something went wrong!',
      });
    }
    onSubmit(formData);
  };


  useEffect(() => {
    if (isOpen) {
      const fetchData = async () => {
        try {
          const response1 = await axios.get('http://localhost:3003/admin/getAdmin', { headers: { Authorization: `Bearer ${storedToken}` } });
          setAdmin(response1.data);
          const response = await axios.get(`http://localhost:3003/resource/${resourceId}`, { headers: { Authorization: `Bearer ${storedToken}` } });
          const requirement = response.data.data;

          setFormData({
            name: requirement.name,
            organization: requirement.organization,
            email: requirement.email,
            phone: requirement.phone,
          });
        } catch (error) {
          console.error('Error fetching requirement data:', error);
        }
      };

      fetchData();
    }
  }, [isOpen, resourceId, storedToken]);

  return (
    <Modal isOpen={isOpen} onRequestClose={onClose}>
      <div className='requirement-modal'>
        <div className='requirement-title-bar'>
          <h2>Edit Client</h2>
          <span className="close" onClick={onClose}>&times;</span>
          <div className='requirement-modal-title-line'></div>
        </div>
        <form onSubmit={handleSubmit}>
          <div className='modal-inside-container'>
            <table>
              <tbody>
                <tr>
                  <td><label>Name</label></td>
                  <td>:<input type="text" name="name" value={formData.name} onChange={handleChange} /></td>
                </tr>
                <tr>
                  <td><label>Organization</label></td>
                  <td>:<input type="text" name="organization" value={formData.organization} onChange={handleChange} /></td>
                </tr>
                <tr>
                  <td><label>Email</label></td>
                  <td>:<input type="text" name="email" value={formData.email} onChange={handleChange} /></td>
                </tr>
                <tr>
                  <td><label>PhoneNumber</label></td>
                  <td>:<input type="number" name="phone" value={formData.phone} onChange={handleChange} /></td>
                </tr>
              </tbody>
            </table>
          </div>
          <div className='addrequirement-footer'>
            <h3>{admin.name}</h3>
            <button type="submit">Submit</button>
          </div>
        </form>
      </div>
    </Modal>
  );
};

export default EditResourceModal;
