import React, { useEffect, useState } from "react";
import axios from 'axios';
import { Container, Row, Col } from "react-bootstrap";
import Card from "react-bootstrap/Card";
import Swal from 'sweetalert2';
import "../../styles/dashboard/dashboard.css";
import Button from "react-bootstrap/Button";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import AddRequirementModel from './addRequirementModal'
import AssignRequirementModal from './assignRequirementModal'
import ScheduleInterviewModal from './scheduleInterviewModal'
import Modal from 'react-modal';
import {
  faClock,
  faCoins,
  faPlus,
  faCalendar,
  faMapMarkerAlt,
} from "@fortawesome/free-solid-svg-icons";

const Dashboard = () => {

  const [requirements, setRequirements] = useState([]);
  const [pending, setPending] = useState([]);
  const [inProgress, setInProgress] = useState([]);
  const [interview, setInterview] = useState([]);
  const [closure, setClosure] = useState([]);
  const [selectedFilter, setSelectedFilter] = useState('Today');
  const [showAddRequirementModal, setShowAddRequirementModal] = useState(false);
  const [showAssignRequirementModal, setShowAssignRequirementModal] = useState(false);
  const [showInterviewRequirementModal, setShowInterviewRequirementModal] = useState(false);
  const [pendingRequirementId, setPendingRequirementId] = useState(null);
  const [inProgressRequirementId, setInProgressRequirementId] = useState(null);
  const [admin, setAdmin] = useState([])
  const [adminImages, setAdminImages] = useState({});
  const [adminNames, setAdminNames] = useState(null);
  const [hoveredAdminId, setHoveredAdminId] = useState(null);

  Modal.setAppElement('#root');

  const handleMouseEnter = (adminId) => {
    setHoveredAdminId(adminId);
  };

  const handleMouseLeave = () => {
    setHoveredAdminId(null);
  };


  // Functions for handling modal visibility
  const openModal = () => setShowAddRequirementModal(true);
  const closeModal = () => setShowAddRequirementModal(false);

  const openAssignModal = (requirementId) => {
    setPendingRequirementId(requirementId);
    setShowAssignRequirementModal(true);
  };
  const closeAssignModal = () => setShowAssignRequirementModal(false);

  const openInterViewModal = (requirementId) => {
    setInProgressRequirementId(requirementId)
    setShowInterviewRequirementModal(true);
  }
  const closeInterViewModal = () => setShowInterviewRequirementModal(false);

  const storedToken = localStorage.getItem('token')

  // Function to filter data based on the selected time frame
  const filterDataByTimeFrame = (data, timeFrame) => {
    const currentDate = new Date();
    switch (timeFrame) {
      case 'Today':
        return data.filter(item => {
          const createdAtDate = new Date(item.createdAt);
          return createdAtDate.toDateString() === currentDate.toDateString();
        });
      case 'This Week':
        const startOfWeek = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate() - currentDate.getDay());
        const endOfWeek = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate() - currentDate.getDay() + 6);
        return data.filter(item => {
          const createdAtDate = new Date(item.createdAt);
          return createdAtDate >= startOfWeek && createdAtDate <= endOfWeek;
        });
      case 'This Month':
        const startOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
        const endOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
        return data.filter(item => {
          const createdAtDate = new Date(item.createdAt);
          return createdAtDate >= startOfMonth && createdAtDate <= endOfMonth;
        });
      default:
        return data;
    }
  };

  const handleFilterClick = (timeFrame) => {
    setSelectedFilter(timeFrame);
  };

  const fetchRequirement = () => {
    axios.get('http://localhost:3003/requirements', {
      headers: {
        Authorization: `Bearer ${storedToken}`
      }
    })
      .then((response) => {
        // Filter data based on status and time
        const data = response.data.data;
        const pendingData = filterDataByTimeFrame(data.filter(item => item.status === 'pending'), selectedFilter);
        const inProgressData = filterDataByTimeFrame(data.filter(item => item.status === 'inProgress'), selectedFilter);
        const interviewData = filterDataByTimeFrame(data.filter(item => item.status === 'interview'), selectedFilter);
        const closureData = filterDataByTimeFrame(data.filter(item => item.status === 'closure'), selectedFilter);

        setPending(pendingData);
        setInProgress(inProgressData);
        setInterview(interviewData);
        setClosure(closureData);
        setRequirements(data);
      })
      .catch((error) => {
        console.log(error);
      });
  }

  // Function for handling form submission
  const handleAddRequirementSubmit = (formData) => {
    axios.post('http://localhost:3003/requirements/add-requirement', formData, {
      headers: {
        Authorization: `Bearer ${storedToken}`
      }
    })
      .then((response) => {
        fetchRequirement();
        console.log("Requirement added")
        Swal.fire({
          title: 'Requirement added!',
          text: 'The requirement have been added.',
          icon: 'success'
        }).then(() => {
          fetchRequirement();
        });
      })
      .catch((error) => {
        console.log(error);
      });
    closeModal();
  };

  const handleAssignRequirementSubmit = async (formData) => {
    // fetchRequirement();
    closeAssignModal();
    // window.location.reload();
    Swal.fire({
      title: 'Requirement Assigned',
      text: 'The requirement have been assigned.',
      icon: 'success'
    }).then(() => {
      fetchRequirement();
    });
  };
  const handleInterviewRequirementSubmit = () => {
    fetchRequirement();
    closeInterViewModal();

  }

  const reScheduleRequirement = (item) => {
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, re-schedule!'
    }).then((result) => {
      if (result.isConfirmed) {
        axios.put(`http://localhost:3003/requirements/${item._id}`, {
          assignedBy: 'null',
          clientId: 'null',
          resourceId: 'null',
          status: 'pending',
          InterviewTime: 'null',
          InterviewDate: 'null',
        },
          {
            headers: {
              Authorization: `Bearer ${storedToken}`
            }
          })
          .then((response) => {
            Swal.fire({
              title: 'Re-Scheduled!',
              text: 'The requirement have been re-scheduled.',
              icon: 'success'
            }).then(() => {
              fetchRequirement();
            });
          })
          .catch((error) => {
            console.log(error);
          });
      }
    });
  }

  const closureRequirement = (item) => {
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Closure!'
    }).then((result) => {
      if (result.isConfirmed) {
        axios.put(`http://localhost:3003/requirements/${item._id}`, {
          status: 'closure'
        },
          {
            headers: {
              Authorization: `Bearer ${storedToken}`
            }
          })
          .then((response) => {
            Swal.fire({
              title: 'Closure!',
              text: 'The requirement have been closed successfully',
              icon: 'success'
            }).then(() => {
              fetchRequirement();
            });
          })
          .catch((error) => {
            console.log(error);
          });
      }
    });
  }

  useEffect(() => {
    axios.get('http://localhost:3003/requirements', {
      headers: {
        Authorization: `Bearer ${storedToken}`
      }
    })
      .then((response) => {
        // Filter data based on status and time
        const data = response.data.data;
        const pendingData = filterDataByTimeFrame(data.filter(item => item.status === 'pending'), selectedFilter);
        const inProgressData = filterDataByTimeFrame(data.filter(item => item.status === 'inProgress'), selectedFilter);
        const interviewData = filterDataByTimeFrame(data.filter(item => item.status === 'interview'), selectedFilter);
        const closureData = filterDataByTimeFrame(data.filter(item => item.status === 'closure'), selectedFilter);

        setPending(pendingData);
        setInProgress(inProgressData);
        setInterview(interviewData);
        setClosure(closureData);
        setRequirements(data);
      })
      .catch((error) => {
        console.log(error);
      });

    axios.get('http://localhost:3003/admin/getAdmin', { headers: { Authorization: `Bearer ${storedToken}` } })
      .then((response) => {
        setAdmin(response.data);
      })
      .catch((error => {
        console.error('Error fetching admin data:', error);
      }))

    // Fetch all admin profiles and store their images
    axios.get('http://localhost:3003/admin/getAll', { headers: { Authorization: `Bearer ${storedToken}` } })
      .then((response) => {
        const adminData = response.data;
        const adminImagesData = {};
        adminData.forEach(admin => {
          adminImagesData[admin._id || admin.id] = admin.image;
        });
        const adminNames = {};
        adminData.forEach(admin => {
          adminNames[admin._id || admin.id] = admin.name;
        });
        setAdminNames(adminNames);
        setAdminImages(adminImagesData);
      })
      .catch((error) => {
        console.log('Error fetching admin data:', error);
      });

  }, [storedToken, selectedFilter]);

  return (
    <div className="dashboard-container">
      <div className="top-line"></div>
      <Container fluid>
        <Row>
          <Col className="mt-5">
            <div className="top-filter">
              <Button className="dashboard-btn1" onClick={() => handleFilterClick('Today')}>Today</Button>
              <Button className="dashboard-btn2" onClick={() => handleFilterClick('This Week')}>This Week</Button>
              <Button className="dashboard-btn3" onClick={() => handleFilterClick('This Month')}>This Month</Button>
            </div>
            <div className="top-profiles">
              <img src={admin.image} className="dashboard-admin-img1" alt="admin1" />
            </div>
          </Col>
        </Row>
        <Row className="mt-5">
          <Col className="dashboard-box p-3">
            <div className="progressTitle">
              <h5 className="dashboard-h5">Requirement</h5>
              <div className="icon-container">
                <FontAwesomeIcon icon={faPlus} className="plus-icon" onClick={openModal} />
                <AddRequirementModel
                  isOpen={showAddRequirementModal}
                  onClose={closeModal}
                  onSubmit={handleAddRequirementSubmit}
                />
              </div>
            </div>
            {pending.map((item, index) => (
              <div key={index} className="cardIndex">
                <Card
                  style={{ width: "18rem", height: "347px", marginLeft: "12px" }}
                  className="mt-3"
                >
                  <Card.Body>
                    <Card.Title className="card-title">{item.role}</Card.Title>
                    <a href="#null">Team Plus India</a>
                    <Card.Text>
                      {item.description.length > 60 ? `${item.description.slice(0, 60)}...` : item.description}
                    </Card.Text>
                    <div className="dashboard-box-ic">
                      <FontAwesomeIcon icon={faCalendar} className="dashboard-card-ic1" />
                      <span className="dashboard-card-span">{item.experience}</span>
                      <FontAwesomeIcon icon={faCoins} className="dashboard-card-ic2" />
                      <span className="dashboard-card-span">{item.salary}</span>
                    </div>
                    <FontAwesomeIcon icon={faMapMarkerAlt} className="dashboard-card-ic3" />
                    <span className="dashboard-card-span">{item.workLocation}</span>
                    <div className="card-footer-line"></div>
                    <div className="assign-button">
                      <Button variant="primary" onClick={() => openAssignModal(item._id)}>Assign</Button>
                      <AssignRequirementModal
                        isOpen={showAssignRequirementModal}
                        onClose={closeAssignModal}
                        onSubmit={handleAssignRequirementSubmit}
                        pendingRequirementId={pendingRequirementId}
                      />
                    </div>
                    <div className="containerImage">
                      {adminImages[item.createdBy] && (
                        <div className="adminImageWrapper" onMouseEnter={() => handleMouseEnter(item.createdBy)} onMouseLeave={handleMouseLeave}>
                          <img src={adminImages[item.createdBy]} className="dashboard-box-admin-img2" alt={`Admin ${item.createdBy}`} />
                          {hoveredAdminId === item.createdBy && <div className="adminNameTooltip"><span>{adminNames[item.createdBy]}</span></div>}
                        </div>
                      )}
                    </div>
                  </Card.Body>
                </Card>
              </div>
            ))}
          </Col>
          <Col className="dashboard-box p-3">
            <div className="progressTitle">
              <h5 className="dashboard-h5">Inprogress</h5>
            </div>
            {inProgress.map((item, index) => (
              <div key={index}>
                <Card
                  style={{ width: "18rem", height: "347px", marginLeft: "12px" }}
                  className="mt-3"
                >
                  <Card.Body>
                    <Card.Title className="card-title">{item.role}</Card.Title>
                    <a href="#null">Team Plus India</a>
                    <Card.Text>
                      {item.description.length > 60 ? `${item.description.slice(0, 60)}...` : item.description}
                    </Card.Text>
                    <div className="dashboard-box-ic">
                      <FontAwesomeIcon icon={faCalendar} className="dashboard-card-ic1" />
                      <span className="dashboard-card-span">{item.experience}</span>
                      <FontAwesomeIcon icon={faCoins} className="dashboard-card-ic2" />
                      <span className="dashboard-card-span">{item.salary}</span>
                    </div>
                    <FontAwesomeIcon icon={faMapMarkerAlt} className="dashboard-card-ic3" />
                    <span className="dashboard-card-span">{item.workLocation}</span>
                    <div className="card-footer-line"></div>
                    <div className="scheduleInterviewButtonContainer">
                      <Button variant="primary" className="scheduleButton" onClick={() => openInterViewModal(item._id)} >Schedule Interview</Button>
                      <ScheduleInterviewModal
                        isOpen={showInterviewRequirementModal}
                        onClose={closeInterViewModal}
                        onSubmit={handleInterviewRequirementSubmit}
                        inProgressRequirementId={inProgressRequirementId}
                      />
                    </div>
                    <div className="containerImage">
                      {(adminImages[item.createdBy] || adminImages[item.createdBy]) && (
                        <div className="adminImageWrapper" onMouseEnter={() => handleMouseEnter(item.createdBy)} onMouseLeave={handleMouseLeave}>
                          <img src={adminImages[item.createdBy]} className="dashboard-box-admin-img1" alt={`Admin ${item.createdBy}`} />
                          <img src={adminImages[item.assignedBy]} className="dashboard-box-admin-img2" alt={`Admin ${item.assignedBy}`} />
                          {hoveredAdminId === item.createdBy &&
                            <div className="adminNameTooltip">
                              <span>{adminNames[item.createdBy]}</span>
                              <span>{adminNames[item.assignedBy]}</span>
                            </div>}
                        </div>
                      )}
                    </div>
                  </Card.Body>
                </Card>
              </div>
            ))}
          </Col>
          <Col className="dashboard-box p-3">
            <div className="progressTitle">
              <h5 className="dashboard-h5">Interview</h5>
            </div>
            {interview.map((item, index) => (
              <div key={index}>
                <Card
                  style={{ width: "18rem", height: "347px", marginLeft: "12px" }}
                  className="mt-3"
                >
                  <Card.Body>
                    <Card.Title className="card-title">{item.role}</Card.Title>
                    <a href="#null">Team Plus India</a>
                    <Card.Text>
                      {item.description.length > 60 ? `${item.description.slice(0, 60)}...` : item.description}
                    </Card.Text>
                    <div className="dashboard-box-ic">
                      <FontAwesomeIcon icon={faCalendar} className="dashboard-card-ic1" />
                      <span className="dashboard-card-span">{item.experience}</span>
                      <FontAwesomeIcon icon={faCoins} className="dashboard-card-ic2" />
                      <span className="dashboard-card-span">{item.salary}</span>
                    </div>
                    <FontAwesomeIcon icon={faMapMarkerAlt} className="dashboard-card-ic3" />
                    <span className="dashboard-card-span">{item.workLocation}</span>
                    <span className="Date-And-Time">
                      <FontAwesomeIcon icon={faClock} className="dashboard-card-ic4" />
                      <h6>Date: {new Date(item.interviewDate).toLocaleDateString()}</h6>
                      <h6>Time: {item.interviewTime}</h6>
                    </span>
                    <div className="card-footer-line"></div>
                    <div className="assign-button-interview">
                      <Button variant="primary" className="reSchedule" onClick={() => reScheduleRequirement(item)}>Reschedule</Button>
                      <Button variant="primary" onClick={() => closureRequirement(item)}>Closure</Button>
                    </div>
                    <div className="containerImage">
                      {(adminImages[item.createdBy] || adminImages[item.createdBy]) && (
                        <div className="adminImageWrapper" onMouseEnter={() => handleMouseEnter(item.createdBy)} onMouseLeave={handleMouseLeave}>
                          <img src={adminImages[item.createdBy]} className="dashboard-box-admin-img1" alt={`Admin ${item.createdBy}`} />
                          <img src={adminImages[item.assignedBy]} className="dashboard-box-admin-img2" alt={`Admin ${item.assignedBy}`} />
                          {hoveredAdminId === item.createdBy &&
                            <div className="adminNameTooltip">
                              <span>{adminNames[item.createdBy]}</span>
                              <span>{adminNames[item.assignedBy]}</span>
                            </div>}
                        </div>
                      )}
                    </div>
                  </Card.Body>
                </Card>
              </div>
            ))}
          </Col>
          <Col className="dashboard-box p-3">
            <div className="progressTitle">
              <h5 className="dashboard-h5">Closure</h5>
            </div>
            {closure.map((item, index) => (
              <div key={index}>
                <Card
                  style={{ width: "18rem", height: "347px", marginLeft: "12px" }}
                  className="mt-3"
                >
                  <Card.Body>
                    <Card.Title className="card-title">{item.role}</Card.Title>
                    <a href="#null">Team Plus India</a>
                    <Card.Text>
                      {item.description.length > 60 ? `${item.description.slice(0, 60)}...` : item.description}
                    </Card.Text>
                    <div className="dashboard-box-ic">
                      <FontAwesomeIcon icon={faCalendar} className="dashboard-card-ic1" />
                      <span className="dashboard-card-span">{item.experience}</span>
                      <FontAwesomeIcon icon={faCoins} className="dashboard-card-ic2" />
                      <span className="dashboard-card-span">{item.salary}</span>
                    </div>
                    <FontAwesomeIcon icon={faMapMarkerAlt} className="dashboard-card-ic3" />
                    <span className="dashboard-card-span">{item.workLocation}</span>
                    <div className="card-footer-line"></div>
                    <div className="containerImage">
                      {(adminImages[item.createdBy] || adminImages[item.createdBy]) && (
                        <div className="adminImageWrapper" onMouseEnter={() => handleMouseEnter(item.createdBy)} onMouseLeave={handleMouseLeave}>
                          <img src={adminImages[item.createdBy]} className="dashboard-box-admin-img1" alt={`Admin ${item.createdBy}`} />
                          <img src={adminImages[item.assignedBy]} className="dashboard-box-admin-img2" alt={`Admin ${item.assignedBy}`} />
                          {hoveredAdminId === item.createdBy &&
                            <div className="adminNameTooltip">
                              <span>{adminNames[item.createdBy]}</span>
                              <span>{adminNames[item.assignedBy]}</span>
                            </div>}
                        </div>
                      )}
                    </div>
                  </Card.Body>
                </Card>
              </div>
            ))}
          </Col>

        </Row>
      </Container>
    </div>
  );
};

export default Dashboard;

