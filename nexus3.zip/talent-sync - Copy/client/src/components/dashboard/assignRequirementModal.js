import axios from 'axios';
import React, { useEffect, useState } from 'react';
import Modal from 'react-modal';
import '../../styles/dashboard/addRequirementModal.css'

const AssignRequirementModal = ({ isOpen, onClose, onSubmit, pendingRequirementId }) => {
  const storedToken = localStorage.getItem('token')
  const [admin, setAdmin] = useState([])

  const [formData, setFormData] = useState({
    role: '',
    position: '',
    salary: '',
    location: '',
    description: '',
    experience: '',
    workLocation: '',
    assignedBy: 'null',
    status: 'inProgress'
  });


  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };


  const handleSubmit = (e) => {
    e.preventDefault();

    axios.put(`http://localhost:3003/requirements/${pendingRequirementId}`, formData, {
      headers: {
        Authorization: `Bearer ${storedToken}`
      }
    })
      .then((response) => {
        console.log("Requirement assigned successfully");
        setFormData({
          role: '',
          position: '',
          salary: '',
          location: '',
          description: '',
          experience: '',
          workLocation: '',
          assignedBy: 'null',
          status: 'inProgress'
        })
      })
      .catch((error) => {
        console.log(error);
      });
    onSubmit(formData);
  };

  useEffect(() => {
    if (isOpen) {
      const fetchData = async () => {
        try {
          const response1 = await axios.get('http://localhost:3003/admin/getAdmin', { headers: { Authorization: `Bearer ${storedToken}` } });
          setAdmin(response1.data);
          const response = await axios.get(`http://localhost:3003/requirements/${pendingRequirementId}`, { headers: { Authorization: `Bearer ${storedToken}` } });
          const requirement = response.data.data;
          setFormData({
            role: requirement.role,
            position: requirement.position,
            salary: requirement.salary,
            location: requirement.location,
            description: requirement.description,
            experience: requirement.experience,
            workLocation: requirement.workLocation,
            assignedBy: response1.data._id || response1.data.id,
            status: 'inProgress'
          })

        } catch (error) {
          console.error('Error fetching requirement data:', error);
        }
      };

      fetchData();
    }
  }, [isOpen, storedToken, pendingRequirementId]);


  return (
    <Modal isOpen={isOpen} onRequestClose={onClose}>
      <div className='requirement-modal'>
        <div className='requirement-title-bar'>
          <h2>Assign</h2>
          <span className="close" onClick={onClose}>&times;</span>
          <div className='requirement-modal-title-line'></div>
        </div>
        <form onSubmit={handleSubmit}>
          <div className='modal-inside-container'>

            <table>
              <tbody>
                <tr>
                  <td><label>Role</label></td>
                  <td>:<input type="text" name="role" value={formData.role} onChange={handleChange} /></td>
                </tr>
                <tr>
                  <td><label>Position</label></td>
                  <td>:<input type="text" name="position" value={formData.position} onChange={handleChange} /></td>
                </tr>
                <tr>
                  <td><label>Salary</label></td>
                  <td>:<input type="text" name="salary" value={formData.salary} onChange={handleChange} /></td>
                </tr>
                <tr>
                  <td><label>Location</label></td>
                  <td>:<input type="text" name="location" value={formData.location} onChange={handleChange} /></td>
                </tr>
                <tr>
                  <td><label>Experience</label></td>
                  <td>:<input type="text" name="experience" value={formData.experience} onChange={handleChange} /></td>
                </tr>
                <tr>
                  <td><label>Work Location</label></td>
                  <td>:<input type="text" name="workLocation" value={formData.workLocation} onChange={handleChange} /></td>
                </tr>
                <tr>
                  <td>
                    <label>Description</label>
                  </td>
                  <td>:</td>
                </tr>
              </tbody>
            </table>
            <div className='description-container'>
              <textarea name="description" value={formData.description} onChange={handleChange} />
            </div>
          </div>
          <div className='addrequirement-footer'>
            <h3>{admin.name}</h3>
            <button type="submit">Submit</button>
          </div>

        </form>

      </div>
    </Modal>
  );
};

export default AssignRequirementModal;
